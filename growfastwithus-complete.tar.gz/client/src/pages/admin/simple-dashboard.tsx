import CleanAdminPanel from "@/components/admin/clean-admin-panel";

export default function SimpleDashboard() {
  return <CleanAdminPanel />;
}